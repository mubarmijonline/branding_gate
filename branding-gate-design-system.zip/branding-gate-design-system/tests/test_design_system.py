from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def read(path):
    return (ROOT / path).read_text(encoding="utf-8")


def test_design_system_assets_are_wired_into_shared_templates():
    css = ROOT / "static/css/branding-gate-system.css"
    spec = ROOT / "docs/design-system/README.md"
    macros = ROOT / "templates/design_system/macros.html"

    assert css.exists()
    assert spec.exists()
    assert macros.exists()

    for token in (
        "--bg-brand-primary",
        "--bg-status-success",
        ".bg-shell",
        ".bg-data-table",
        ".bg-detail-drawer",
        ".modal-xl .modal-dialog",
    ):
        assert token in css.read_text(encoding="utf-8")

    assert "branding-gate-system.css" in read("templates/main.html")
    assert "branding-gate-system.css" in read("templates/login.html")
    assert "branding-gate-system.css" in read("templates/register.html")
    assert 'class="bg-shell"' in read("templates/main.html")
    assert "page_header" in macros.read_text(encoding="utf-8")


def test_main_design_system_css_loads_after_inline_shell_styles():
    source = read("templates/main.html")
    head = source[: source.index("</head>")]

    assert head.rfind("branding-gate-system.css") > head.rfind("</style>")
    assert head.rfind("branding-gate-system.css") > head.rfind("{% block head %}")


def test_global_tables_inherit_scroll_drag_system():
    css = read("static/css/branding-gate-system.css")
    shell = read("templates/main.html")

    assert ".table-responsive.bg-table-dragging" in css
    assert ".dataTables_wrapper.bg-table-dragging" in css
    assert "table.finance-table" in css
    assert "table.transfers-table" in css
    assert "function getBgTableScrollTarget" in shell
    assert "pointerdown.bgTableDrag" in shell
    assert "setPointerCapture" in shell
    assert "table-responsive, .dataTables_scrollBody, .dataTables_wrapper, table.finance-table" in shell


def test_full_pages_extend_the_shared_shell():
    standalone = {"main.html", "login.html", "register.html", "comments_widget.html"}
    for template in (ROOT / "templates").glob("*.html"):
        if template.name in standalone:
            continue
        source = template.read_text(encoding="utf-8", errors="ignore")
        assert (
            'extends "main.html"' in source or "extends 'main.html'" in source
        ), f"{template.name} must extend main.html to inherit the design system"


def test_sales_request_table_is_mobile_and_scroll_friendly():
    source = read("templates/sales_request.html")

    assert "sales-request-page" in source
    assert '"scrollX": false' in source
    assert '"autoWidth": false' in source
    assert "attachSalesRequestTopScroller" in source
    assert "enableSalesRequestDragScroll" in source
    assert "pointermove.salesRequestDrag" in source
    assert "setPointerCapture" in source
    assert "e.preventDefault();" in source
    assert "sales-request-table-final-overrides" in source
    assert "sales-request-table-admin" in source
    assert "min-width: 2360px" in source
    assert "col.srq-col-title" in source
    assert "data-label" in source
    assert ".sales-request-mobile-card" in source
    assert "@media (max-width: 768px)" in source


if __name__ == "__main__":
    test_design_system_assets_are_wired_into_shared_templates()
    test_main_design_system_css_loads_after_inline_shell_styles()
    test_global_tables_inherit_scroll_drag_system()
    test_full_pages_extend_the_shared_shell()
    test_sales_request_table_is_mobile_and_scroll_friendly()
